# LORE.CO – Premium Graphic Design Platform

Professional online graphic design service platform.

**Brand colours**
- Primary: Ocean Blue `#2563EB`
- White: `#FFFFFF`
- Dark Navy: `#0F172A`

## Pages included

- Home
- Services
- Service Detail
- Portfolio
- About
- Pricing
- Contact
- FAQ
- Login
- Sign Up
- Forgot Password

## How to test on Android (Important)

### Method 1 – Using SimpleHttpServer (Recommended)

1. Download and unzip **LORE.CO-Website.zip**
2. Open the **SimpleHttpServer** app
3. Stop the current server if it is running
4. Change the shared folder to the **lore-co** folder (the one that contains `index.html`)
5. Start the server
6. Open the link it shows (example: `http://192.168.x.x:8080`)

**Important:** Make sure the folder you select contains these items:
- index.html
- css (folder)
- js (folder)
- other .html files

If you select the wrong folder, the design will not load.

### Method 2 – HTML Viewer app

1. Install “HTML Viewer” from Play Store
2. Open the `index.html` file with that app

### Method 3 – Computer

Just open `index.html` in Chrome or any browser.

## Current Status

✅ Complete premium public website  
✅ Mobile responsive  
✅ Forms + navigation working  
⏳ Customer dashboard (next)  
⏳ Admin dashboard (next)  
⏳ Supabase + Paystack (later)

---

Built for LORE.CO
